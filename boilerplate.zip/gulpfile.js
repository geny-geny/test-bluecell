/**
 * Load NPM dependencies
*/
var gulp         = require('gulp');
var sass         = require('gulp-sass');
var browserSync  = require('browser-sync').create();
var uglify       = require('gulp-uglifyjs');
var postcss      = require('gulp-postcss');
var autoprefixer = require('autoprefixer');
var cssnano      = require('cssnano');
const nunjucks   = require('gulp-nunjucks');
const data       = require('gulp-data');
var fs           = require('fs');
var compass      = require('gulp-compass');

var processors = [
  autoprefixer,
  cssnano
];

gulp.task('sass', function () {
  return gulp.src(['src/scss/*.scss'])
  .pipe(compass({
    sass: 'src/scss'
  }))
  .pipe(sass().on('error', sass.logError))
  .pipe(postcss(processors))
  .pipe(gulp.dest("dist/css"))
  .pipe(browserSync.stream());
});

gulp.task('js', function() {
  return gulp.src(['node_modules/jquery/dist/jquery.min.js', 'src/js/src/*.js'])
  .pipe(uglify('self.min.js', {
    outSourceMap: false
  }))
  .pipe(gulp.dest("dist/js"))
  .pipe(browserSync.stream());
});

gulp.task('html', function() {
  gulp.src(['src/*.html'])
  .pipe(data(function() {
    // return require('./src/data.json');
    return JSON.parse(fs.readFileSync('./src/data.json'));
  }))
  .pipe(nunjucks.compile())
  .pipe(gulp.dest('dist'))
  .pipe(browserSync.stream())
});

gulp.task('serve', ['sass'], function(){
  browserSync.init({
    server: "./dist"
  });
  gulp.watch(['src/scss/*.scss','src/scss/*/*.scss'], ['sass']);
  gulp.watch(['src/js/src/*.js'], ['js']);
  gulp.watch(['src/templates/*.njk','src/*.html','src/data.json'], ['html']);
  gulp.watch("src/*.html").on('change', browserSync.reload);
});

gulp.task('live', ['html','serve']);